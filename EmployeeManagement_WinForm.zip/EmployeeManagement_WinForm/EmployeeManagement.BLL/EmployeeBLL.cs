﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EmployeeManagement.Entities;
using EmployeeManagement.Exceptions;
using EmployeeManagement.DAL;
using System.Text.RegularExpressions;
namespace EmployeeManagement.BLL
{
    public class EmployeeBLL
    {
        EmployeeOperations EmployeeOperationsDAL;
        public EmployeeBLL()
        {
            EmployeeOperationsDAL = new EmployeeOperations();
        }
        private bool ValidateEmployee(Employee employeeObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[a-zA-Z\\s]{3,25}$");
            if (string.IsNullOrEmpty(employeeObj.Name) || !RegExObj.IsMatch(employeeObj.Name))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only single space is allowed");
            }
            if (employeeObj.DateOfJoining.Date != DateTime.Now.Date)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Date of joining should be todays date");
            }
            int Age = DateTime.Now.Year - employeeObj.DateOfBirth.Year;
            if (Age < 23 || Age > 58)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Age should be between 23 and 58");
            }
            var Designation = employeeObj.Designation.ToLower();
            if (!Designation.Equals("software engineer") && !Designation.Equals("trainee") && !Designation.Equals("tester"))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Invalid designation. Only Software Engineer, Trainee, Tester is allowed");
            }
            if (IsValid == false)
            {
                throw new EmployeeManagementException(ErrorMessages.ToString());
            }

            return IsValid;
        }

        public bool Add(Employee employeeObj)
        {
            var IsSaved = false;
            try
            {
                if (ValidateEmployee(employeeObj))
                {
                    switch (employeeObj.Designation.ToLower())
                    {
                        case "software engineer":
                            employeeObj.Salary = 50000;
                            break;
                        case "tester":
                            employeeObj.Salary = 40000;
                            break;
                        default:
                            employeeObj.Salary = 15555.55m;
                            break;
                    }
                    
                    IsSaved = EmployeeOperationsDAL.AddEmployee(employeeObj);
                }
            }
            catch (EmployeeManagementException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Unknown error", ex);
            }
            return IsSaved;
        }

        public List<Employee> GetAll()
        {
            var EmployeesList = new List<Employee>();
            try
            {
                var ObjDAL = new EmployeeOperations();
                EmployeesList = ObjDAL.GetEmployees();
                if (EmployeesList == null || EmployeesList.Count == 0)
                    throw new EmployeeManagementException("Employees not found");
            }
            catch (EmployeeManagementException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Unknown error", ex);
            }
            return EmployeesList;
        }

        public Employee FindById(int id)
        {
            Employee EmployeeObj = null;
            try
            {
                if (id <= 0)
                    throw new EmployeeManagementException("Id should be greater than 0");

                var ObjDAL = new EmployeeOperations();
                EmployeeObj = ObjDAL.GetEmployee(id);

                if (EmployeeObj == null)
                    throw new EmployeeManagementException("No such employee exists");
            }
            catch (EmployeeManagementException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Error searching employee", ex);
            }
            return EmployeeObj;
        }

        public bool UpdateEmployee(Employee employeeObj)
        {
            var IsUpdated = false;
            try
            {
                if (employeeObj == null)
                    throw new EmployeeManagementException("Employee required for update");
                var ObjDAL = new EmployeeOperations();
                switch (employeeObj.Designation.ToLower())
                {
                    case "software engineer":
                        employeeObj.Salary = 50000;
                        break;
                    case "tester":
                        employeeObj.Salary = 40000;
                        break;
                    default:
                        employeeObj.Salary = 17562.50m;
                        break;
                }
                IsUpdated = ObjDAL.UpdateEmployee(employeeObj);
            }
            catch (EmployeeManagementException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Error editing employee details");
            }
            return IsUpdated;
        }

        public bool Delete(int id)
        {
            var IsDeleted = false;
            try
            {
                if (id <= 0)
                    throw new EmployeeManagementException("Id should be greater than 0");

                var ObjDAL = new EmployeeOperations();
                IsDeleted = ObjDAL.DeleteEmployee(id);
            }
            catch (EmployeeManagementException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Failed to remove employee", ex);
            }
            return IsDeleted;
        }

    }
}
