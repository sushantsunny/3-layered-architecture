﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using EmployeeManagement.Entities;
using EmployeeManagement.Exceptions;
using EmployeeManagement.BLL;
namespace EmployeeManagement.WinFormPL
{
    public partial class FrmEmployeeManagement : Form
    {
        public FrmEmployeeManagement()
        {
            InitializeComponent();
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            var EmployeeObj = new Employee();
            try
            {
                EmployeeObj.Name = txtName.Text;
                EmployeeObj.DateOfBirth = Convert.ToDateTime(dtpDateOfBirth.Text);
                EmployeeObj.DateOfJoining = Convert.ToDateTime(dtpDateOfJoining.Text);
                EmployeeObj.Designation = cmbDesignation.SelectedItem.ToString();
                EmployeeObj.Salary = Convert.ToDecimal(txtSalary.Text);

                var EmployeeBLLObj = new EmployeeBLL();
                var IsAdded = EmployeeBLLObj.Add(EmployeeObj);
                if (IsAdded)
                {
                    MessageBox.Show("Employee added", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FillDataGridView();
                }
                else
                    MessageBox.Show("Employee not added", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (EmployeeManagementException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void FrmEmployeeManagement_Load(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void FillDataGridView()
        {
            try
            {
                var EmployeeBLLObj = new EmployeeBLL();
                var EmployeesList = EmployeeBLLObj.GetAll();
                dgvEmployees.DataSource = EmployeesList;
            }
            catch (EmployeeManagementException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFindEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                var EmployeeBLLObj = new EmployeeBLL();
                var Id = Convert.ToInt32(txtId.Text);
                var EmployeeObj = EmployeeBLLObj.FindById(Id);
                txtName.Text = EmployeeObj.Name;
                dtpDateOfBirth.Text = EmployeeObj.DateOfBirth.Date.ToString();
                dtpDateOfJoining.Text = EmployeeObj.DateOfJoining.Date.ToString();
                cmbDesignation.SelectedItem = EmployeeObj.Designation;
                txtSalary.Text = EmployeeObj.Salary.ToString();
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (EmployeeManagementException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdateEmployee_Click(object sender, EventArgs e)
        {
            var EmployeeObj = new Employee();
            try
            {
                EmployeeObj.Id = Convert.ToInt32(txtId.Text);
                EmployeeObj.Name = txtName.Text;
                EmployeeObj.DateOfBirth = Convert.ToDateTime(dtpDateOfBirth.Text);
                EmployeeObj.DateOfJoining = Convert.ToDateTime(dtpDateOfJoining.Text);
                EmployeeObj.Designation = cmbDesignation.SelectedItem.ToString();
                EmployeeObj.Salary = Convert.ToDecimal(txtSalary.Text);

                var EmployeeBLLObj = new EmployeeBLL();
                var IsUpdated = EmployeeBLLObj.UpdateEmployee(EmployeeObj);
                if (IsUpdated)
                {
                    MessageBox.Show("Employee updated", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FillDataGridView();
                }
                else
                    MessageBox.Show("Employee not updated", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (EmployeeManagementException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                var Id = Convert.ToInt32(txtId.Text);
                var EmployeeBLLObj = new EmployeeBLL();
                var IsDeleted = EmployeeBLLObj.Delete(Id);
                if (IsDeleted)
                {
                    MessageBox.Show("Employee deleted", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FillDataGridView();
                }
                else
                    MessageBox.Show("Employee not deleted", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (EmployeeManagementException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbDesignation_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbDesignation.SelectedItem.ToString())
            {
                case "Software Engineer": txtSalary.Text = "50000"; break;
                case "Tester": txtSalary.Text = "40000"; break;
                default: txtSalary.Text = "15555.55"; break;
            }
        }
    }
}
