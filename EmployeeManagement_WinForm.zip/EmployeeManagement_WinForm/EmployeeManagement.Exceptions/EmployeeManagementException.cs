﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Exceptions
{
    public class EmployeeManagementException : ApplicationException
    {
        public EmployeeManagementException() : base()
        {

        }
        public EmployeeManagementException(string message) : base(message)
        {

        }
        public EmployeeManagementException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
