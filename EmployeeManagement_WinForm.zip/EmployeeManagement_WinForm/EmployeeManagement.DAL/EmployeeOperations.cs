﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using EmployeeManagement.Entities;
using EmployeeManagement.Exceptions;
namespace EmployeeManagement.DAL
{
    public class EmployeeOperations
    {
        SqlConnection ConnectionObj;
        SqlCommand CommandObj;
        SqlDataReader ReaderObj;
        public EmployeeOperations()
        {
            ConnectionObj = new SqlConnection();
            CommandObj = new SqlCommand();
            ConnectionObj.ConnectionString = ConfigurationManager.ConnectionStrings["EMS"].ConnectionString;
            CommandObj.Connection = ConnectionObj;
        }

        public bool AddEmployee(Employee employeeObj)
        {
            var IsAdded = false;
            CommandObj.CommandText = "Syed.uspInsertEmployee";
            CommandObj.CommandType = CommandType.StoredProcedure;

            CommandObj.Parameters.AddWithValue("@Name", employeeObj.Name);
            CommandObj.Parameters.AddWithValue("@DateOfBirth", employeeObj.DateOfBirth.Date);
            CommandObj.Parameters.AddWithValue("@DateOfJoining", employeeObj.DateOfJoining.Date);
            CommandObj.Parameters.AddWithValue("@Designation", employeeObj.Designation);
            CommandObj.Parameters.AddWithValue("@Salary", employeeObj.Salary);

            try
            {
                ConnectionObj.Open();
                var NoOfRowsAffected = CommandObj.ExecuteNonQuery();
                //IsAdded = NoOfRowsAffected == 1;
                //IsAdded = NoOfRowsAffected == 1 ? true : false;
                //if (NoOfRowsAffected > 0)
                //    IsAdded = true;
                //else
                //    IsAdded = false;
                IsAdded = NoOfRowsAffected > 0;
            }
            catch (SqlException ex)
            {
                throw new EmployeeManagementException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Unknown error", ex);
            }
            finally
            {
                //if (ConnectionObj.State != ConnectionState.Closed)
                ConnectionObj.Close();
            }
            return IsAdded;
        }

        public List<Employee> GetEmployees()
        {
            var EmployeesListObj = new List<Employee>();
            CommandObj.CommandText = "Syed.uspSelectEmployees";
            CommandObj.CommandType = CommandType.StoredProcedure;

            try
            {
                ConnectionObj.Open();
                ReaderObj = CommandObj.ExecuteReader();
                if (ReaderObj.HasRows)
                {
                    while (ReaderObj.Read())
                    {
                        var EmployeeObj = new Employee();
                        EmployeeObj.Id = ReaderObj.GetInt32(0);
                        EmployeeObj.Name = ReaderObj.GetString(1);
                        EmployeeObj.DateOfBirth = ReaderObj.GetDateTime(2);
                        EmployeeObj.DateOfJoining = ReaderObj.GetDateTime(3);
                        EmployeeObj.Designation = ReaderObj.GetString(4);
                        EmployeeObj.Salary = ReaderObj.GetDecimal(5);

                        EmployeesListObj.Add(EmployeeObj);
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new EmployeeManagementException("Failed to read data", ex);
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Unknown error reading data", ex);
            }
            finally
            {
                ReaderObj.Close();
                ConnectionObj.Close();
            }
            return EmployeesListObj;
        }

        public Employee GetEmployee(int id)
        {
            Employee EmployeeObj = null;
            CommandObj.CommandText = "Syed.uspSelectEmployeeById";
            CommandObj.CommandType = CommandType.StoredProcedure;
            CommandObj.Parameters.AddWithValue("@Id", id);
            try
            {
                ConnectionObj.Open();
                ReaderObj = CommandObj.ExecuteReader();
                if (ReaderObj.HasRows)
                {
                    ReaderObj.Read();
                    EmployeeObj = new Employee();
                    EmployeeObj.Id = ReaderObj.GetInt32(0);
                    EmployeeObj.Name = ReaderObj.GetString(1);
                    EmployeeObj.DateOfBirth = ReaderObj.GetDateTime(2);
                    EmployeeObj.DateOfJoining = ReaderObj.GetDateTime(3);
                    EmployeeObj.Designation = ReaderObj.GetString(4);
                    EmployeeObj.Salary = ReaderObj.GetDecimal(5);
                }
            }
            catch (SqlException ex)
            {
                throw new EmployeeManagementException("Failed to read data", ex);
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Unknown error reading data", ex);
            }
            finally
            {
                ReaderObj.Close();
                ConnectionObj.Close();
            }
            return EmployeeObj;
        }

        public bool UpdateEmployee(Employee employeeObj)
        {
            var IsUpdated = false;
            CommandObj.CommandText = "Syed.uspUpdateEmployee";
            CommandObj.CommandType = CommandType.StoredProcedure;

            CommandObj.Parameters.AddWithValue("@Id", employeeObj.Id);
            CommandObj.Parameters.AddWithValue("@Name", employeeObj.Name);
            CommandObj.Parameters.AddWithValue("@DateOfBirth", employeeObj.DateOfBirth.Date);
            CommandObj.Parameters.AddWithValue("@DateOfJoining", employeeObj.DateOfJoining.Date);
            CommandObj.Parameters.AddWithValue("@Designation", employeeObj.Designation);
            CommandObj.Parameters.AddWithValue("@Salary", employeeObj.Salary);
            
            try
            {
                ConnectionObj.Open();
                var NoOfRowsAffected = CommandObj.ExecuteNonQuery();
                //IsAdded = NoOfRowsAffected == 1;
                //IsAdded = NoOfRowsAffected == 1 ? true : false;
                //if (NoOfRowsAffected > 0)
                //    IsAdded = true;
                //else
                //    IsAdded = false;
                IsUpdated = NoOfRowsAffected > 0;
            }
            catch (SqlException ex)
            {
                throw new EmployeeManagementException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Unknown error", ex);
            }
            finally
            {
                //if (ConnectionObj.State != ConnectionState.Closed)
                ConnectionObj.Close();
            }
            return IsUpdated;
        }

        public bool DeleteEmployee(int id)
        {
            bool IsDeleted = false;

            CommandObj.CommandText = "Syed.uspDeleteEmployee";
            CommandObj.CommandType = CommandType.StoredProcedure;
            CommandObj.Parameters.AddWithValue("@Id", id);
            try
            {
                ConnectionObj.Open();
                int NoOfRowsAffected = CommandObj.ExecuteNonQuery();
                IsDeleted = NoOfRowsAffected > 0;
            }
            catch (SqlException ex)
            {
                throw new EmployeeManagementException("Failed to read data", ex);
            }
            catch (Exception ex)
            {
                throw new EmployeeManagementException("Unknown error reading data", ex);
            }
            finally
            {
                ConnectionObj.Close();
            }
            return IsDeleted;
        }
    }
}
