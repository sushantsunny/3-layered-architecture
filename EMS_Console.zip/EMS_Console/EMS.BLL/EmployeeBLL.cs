﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS.Entities;
using EMS.Exceptions;
using EMS.DAL;
using System.Text.RegularExpressions;
namespace EMS.BLL
{
    public class EmployeeBLL
    {
        private bool ValidateEmployee(Employee employeeObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[a-zA-Z\\s]{3,25}$");
            if (employeeObj.Id <= 0)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Id should be greater than 0");
            }
            if (string.IsNullOrEmpty(employeeObj.Name) || !RegExObj.IsMatch(employeeObj.Name))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only single space is allowed");
            }
            if (employeeObj.DateOfJoining.Date != DateTime.Now.Date)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Date of joining should be todays date");
            }
            int Age = DateTime.Now.Year - employeeObj.DateOfBirth.Year;
            if (Age < 21 || Age > 58)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Age should be between 21 and 58");
            }
            var Designation = employeeObj.Designation.ToLower();
            if(!Designation.Equals("software engineer") && !Designation.Equals("trainee") && !Designation.Equals("tester"))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Invalid designation. Only Software Engineer, Trainee, Tester is allowed");
            }

            if(IsValid==false)
            {
                throw new EmployeeException(ErrorMessages.ToString());
            }

            return IsValid;
        }

        public bool Add(Employee employeeObj)
        {
            var IsSaved = false;
            try
            {
                if(ValidateEmployee(employeeObj))
                {
                    switch (employeeObj.Designation.ToLower())
                    {
                        case "software engineer":
                            employeeObj.Salary = 50000;
                            break;
                        case "tester":
                            employeeObj.Salary = 40000;
                            break;
                        default:
                            employeeObj.Salary = 17562.50;
                            break;
                    }
                    var DALObj = new EmployeeDAL();
                    IsSaved = DALObj.Add(employeeObj);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw new EmployeeException("Unknown error", ex);
            }
            return IsSaved;
        }

        public List<Employee> GetAll()
        {
            var EmployeesList = new List<Employee>();
            try
            {
                var ObjDAL = new EmployeeDAL();
                EmployeesList = ObjDAL.GetAll();
                if (EmployeesList == null || EmployeesList.Count == 0)
                    throw new EmployeeException("Employees not found");
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw new EmployeeException("Unknown error", ex);
            }
            return EmployeesList;
        }

        public Employee FindById(int id)
        {
            Employee EmployeeObj = null;
            try
            {
                if (id <= 0)
                    throw new EmployeeException("Id should be greater than 0");

                var ObjDAL = new EmployeeDAL();
                EmployeeObj = ObjDAL.FindById(id);

                if (EmployeeObj == null)
                    throw new EmployeeException("No such employee exists");
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw new EmployeeException("Error searching employee", ex);
            }
            return EmployeeObj;
        }

        public bool UpdateEmployee(Employee employeeObj)
        {
            var IsUpdated = false;
            try
            {
                if (employeeObj == null)
                    throw new EmployeeException("Employee required for update");
                var ObjDAL = new EmployeeDAL();
                switch (employeeObj.Designation.ToLower())
                {
                    case "software engineer":
                        employeeObj.Salary = 50000;
                        break;
                    case "tester":
                        employeeObj.Salary = 40000;
                        break;
                    default:
                        employeeObj.Salary = 17562.50;
                        break;
                }
                IsUpdated = ObjDAL.Update(employeeObj);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw new EmployeeException("Error editing employee details");
            }
            return IsUpdated;
        }

        public bool Delete(int id)
        {
            var IsDeleted = false;
            try
            {
                if (id <= 0)
                    throw new EmployeeException("Id should be greater than 0");

                var ObjDAL = new EmployeeDAL();
                IsDeleted = ObjDAL.Delete(id);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw new EmployeeException("Failed to remove employee", ex);
            }
            return IsDeleted;
        }
        public void SaveToBinaryFile()
        {
            try
            {
                var ObjDAL = new EmployeeDAL();
                ObjDAL.SerializeToBinary();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public void ReadFromBinaryFile()
        {
            try
            {
                var ObjDAL = new EmployeeDAL();
                ObjDAL.DeSerializeFromBinary();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void SaveToSoapFile()
        {
            try
            {
                var ObjDAL = new EmployeeDAL();
                ObjDAL.SerializeToSoap();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void ReadFromSoapFile()
        {
            try
            {
                var ObjDAL = new EmployeeDAL();
                ObjDAL.DeSerializeFromSoap();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
