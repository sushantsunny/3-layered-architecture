﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entities
{
    [Serializable]
    public class Employee : IComparable<Employee>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
        public DateTime DateOfJoining { get; set; }
        public string Designation { get; set; }
        public double Salary { get; set; }
        public Employee()
        {

        }

        public int CompareTo(Employee other)
        {
            return this.Id.CompareTo(other.Id);
        }
    }
}
