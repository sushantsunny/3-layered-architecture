﻿/*  FileName : EmployeeException.cs
 *  Created On :  18-Oct-2017
 *  Author : Khaleelullah Hussaini Syed
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exceptions
{
    /// <summary>
    /// Class to raise user-defined exceptions
    /// </summary>
    public class EmployeeException : ApplicationException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public EmployeeException() : base()
        {

        }
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="message">Message to initialize</param>
        public EmployeeException(string message) : base(message)
        {

        }
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="message">Exception message</param>
        /// <param name="innerException">Inner exception if any</param>
        public EmployeeException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
