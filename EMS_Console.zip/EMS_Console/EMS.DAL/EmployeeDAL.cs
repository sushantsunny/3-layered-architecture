﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using EMS.Entities;
using EMS.Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
namespace EMS.DAL
{
    public class EmployeeDAL
    {
        static List<Employee> EmployeesList = new List<Employee>();
        public bool Add(Employee employeeObj)
        {
            var IsSaved = false;
            try
            {
                EmployeesList.Add(employeeObj);
                IsSaved = true;
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Failed to add employee", ex);
            }
            return IsSaved;
        }

        public List<Employee> GetAll()
        {
            try
            {
                return EmployeesList;
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Failed to get employees");
            }
        }
        public Employee FindById(int id)
        {
            Employee EmployeeObj = null;
            try
            {
                EmployeeObj = EmployeesList.Find(e => e.Id == id);
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Failed to search", ex);
            }
            return EmployeeObj;
        }

        public bool Update(Employee employeeObj)
        {
            var IsUpdated = false;
            try
            {
                var EmployeeToEdit = EmployeesList.Find(e => e.Id == employeeObj.Id);
                if (EmployeeToEdit != null)
                {
                    EmployeeToEdit.Name = employeeObj.Name;
                    EmployeeToEdit.DateOfBirth = employeeObj.DateOfBirth;
                    EmployeeToEdit.Designation = employeeObj.Designation;
                    EmployeeToEdit.Salary = employeeObj.Salary;
                    IsUpdated = true;
                }
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Failed to edit", ex);
            }
            return IsUpdated;
        }

        public bool Delete(int id)
        {
            var IsDeleted = false;
            try
            {
                var Index = EmployeesList.BinarySearch(new Employee { Id = id });
                EmployeesList.RemoveAt(Index);
                IsDeleted = true;
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Error deleting employee", ex);
            }
            return IsDeleted;
        }

        public void SerializeToBinary()
        {
            try
            {
                using (var StreamObj = new FileStream("EmployeesList.dat", FileMode.Create, FileAccess.Write))
                {
                    var Formatter = new BinaryFormatter();
                    Formatter.Serialize(StreamObj, EmployeesList.ToArray());
                    StreamObj.Close();
                }
            }
            catch (IOException ex)
            {
                throw new EmployeeException("Failed to access file", ex);
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Unknow error while saving to file", ex);
            }
        }
        public void DeSerializeFromBinary()
        {
            try
            {
                using (var StreamObj = new FileStream("EmployeesList.dat", FileMode.Open, FileAccess.Read))
                {
                    var Formatter = new BinaryFormatter();
                    var Employees = ((Employee[])Formatter.Deserialize(StreamObj));
                    EmployeesList.Clear();
                    EmployeesList.AddRange(Employees);
                    StreamObj.Close();
                }
            }
            catch (IOException ex)
            {
                throw new EmployeeException("Failed to access file", ex);
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Unknow error while saving to file", ex);
            }
        }

        public void SerializeToSoap()
        {
            try
            {
                using (var StreamObj = new FileStream("EmployeesList.xml", FileMode.Create, FileAccess.Write))
                {
                    var Formatter = new SoapFormatter();
                    Formatter.Serialize(StreamObj, EmployeesList.ToArray());
                    StreamObj.Close();
                }
            }
            catch (IOException ex)
            {
                throw new EmployeeException("Failed to access file", ex);
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Unknow error while saving to file", ex);
            }
        }
        public void DeSerializeFromSoap()
        {
            try
            {
                using (var StreamObj = new FileStream("EmployeesList.xml", FileMode.Open, FileAccess.Read))
                {
                    var Formatter = new SoapFormatter();
                    var Employees = ((Employee[])Formatter.Deserialize(StreamObj));
                    EmployeesList.AddRange(Employees);
                    StreamObj.Close();
                }
            }
            catch (IOException ex)
            {
                throw new EmployeeException("Failed to access file", ex);
            }
            catch (Exception ex)
            {
                throw new EmployeeException("Unknow error while saving to file", ex);
            }
        }
    }
}
