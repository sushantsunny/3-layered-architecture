CREATE DATABASE EMS
GO

USE EMS
GO

CREATE SCHEMA Syed
GO

CREATE TABLE Syed.Employees
(
	Id INT CONSTRAINT pk_Employees_Id PRIMARY KEY,
	Name VARCHAR(25) NOT NULL,
	DateOfBirth DATE NOT NULL,
	DateOfJoining DATE NOT NULL,
	Designation VARCHAR(25) NOT NULL,
	Salary MONEY NOT NULL
)
GO

CREATE SEQUENCE Syed.SEQ_Employees_Id
AS INT
START WITH 1
INCREMENT BY 1
GO

CREATE PROCEDURE Syed.uspInsertEmployee
(
  @Name VARCHAR(25),
  @DateOfBirth DATE,
  @DateOfJoining DATE,
  @Designation VARCHAR(25),
  @Salary MONEY
)
AS 
BEGIN
	INSERT INTO Syed.Employees VALUES(NEXT VALUE FOR Syed.SEQ_Employees_Id, @Name,@DateOfBirth,@DateOfJoining,@Designation,@Salary)
END
GO




CREATE PROCEDURE Syed.uspUpdateEmployee
(
  @Id INT,
  @Name VARCHAR(25),
  @DateOfBirth DATE,
  @DateOfJoining DATE,
  @Designation VARCHAR(25),
  @Salary MONEY
)
AS 
BEGIN
	UPDATE Syed.Employees SET Name=@Name, DateOfBirth=@DateOfBirth, DateOfJoining=@DateOfJoining, Designation=@Designation, Salary=@Salary
	WHERE Id=@Id
END
GO


CREATE PROCEDURE Syed.uspDeleteEmployee
(
 @Id INT
)
AS 
BEGIN
	DELETE FROM Syed.Employees WHERE Id=@Id
END
GO

CREATE PROCEDURE Syed.uspSelectEmployees
AS 
BEGIN
	SELECT * FROM Syed.Employees
END
GO

CREATE PROCEDURE Syed.uspSelectEmployeeById
(
  @Id INT
)
AS 
BEGIN
	SELECT * FROM Syed.Employees WHERE Id=@Id
END
GO