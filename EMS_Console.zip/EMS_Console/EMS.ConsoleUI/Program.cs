﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS.Entities;
using EMS.BLL;
using EMS.Exceptions;
namespace EMS.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int Choice = 0;
            while (Choice != 10)
            {
                PrintMenu();
                try
                {
                    Choice = int.Parse(Console.ReadLine());
                    switch (Choice)
                    {
                        case 1:
                            AddEmployee();
                            break;
                        case 2:
                            DisplayAll();
                            break;
                        case 3:
                            Search();
                            break;
                        case 4:
                            Update();
                            break;
                        case 5:
                            DeleteEmployee();
                            break;
                        case 6:
                            SerializeToBinary();
                            break;
                        case 7:
                            DeSerializeFromBinary();
                            break;
                        case 8:
                            SerializeToSoap();
                            break;
                        case 9:
                            DeSerializeFromSoap();
                            break;
                    }
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Invalid format. Enter integer");
                }
                catch (EmployeeException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            Console.ReadKey();
        }

        private static void DeSerializeFromBinary()
        {
            var ObjBLL = new EmployeeBLL();
            ObjBLL.ReadFromBinaryFile();
        }

        private static void SerializeToBinary()
        {
            var ObjBLL = new EmployeeBLL();
            ObjBLL.SaveToBinaryFile();
        }
        private static void DeSerializeFromSoap()
        {
            var ObjBLL = new EmployeeBLL();
            ObjBLL.ReadFromSoapFile();
        }

        private static void SerializeToSoap()
        {
            var ObjBLL = new EmployeeBLL();
            ObjBLL.SaveToSoapFile();
        }

        private static void DeleteEmployee()
        {
            Console.WriteLine("Enter Id to delete");
            var Id = Convert.ToInt32(Console.ReadLine());

            var ObjBLL = new EmployeeBLL();
            var Deleted = ObjBLL.Delete(Id);
            if (Deleted)
                Console.WriteLine("Employee deleted");
            else
                Console.WriteLine("Failed to delete");
        }

        private static void Update()
        {
            Console.WriteLine("Enter Id, Name, Date Of Birth, Designation");
            var EmployeeObj = new Employee();
            EmployeeObj.Id = Convert.ToInt32(Console.ReadLine());
            EmployeeObj.Name = Console.ReadLine();
            EmployeeObj.DateOfBirth = Convert.ToDateTime(Console.ReadLine());
            EmployeeObj.Designation = Console.ReadLine();

            var ObjBLL = new EmployeeBLL();
            var IsUpdated = ObjBLL.UpdateEmployee(EmployeeObj);
            if (IsUpdated)
                Console.WriteLine("Updated details");
            else
                Console.WriteLine("Update failed");
        }

        private static void Search()
        {
            Console.WriteLine("Enter id to search");

            int Id = Convert.ToInt32(Console.ReadLine());
            var ObjBLL = new EmployeeBLL();
            var Employee = ObjBLL.FindById(Id);
            Console.WriteLine("Id\tName\tDOJ\t\tDOB\t\tDesignation\tSalary");
            Console.WriteLine("----------------------------------------------------------------");
            Console.WriteLine("{0}\t{1}\t{2:d}\t{3:d}\t{4}\t{5}", Employee.Id, Employee.Name, Employee.DateOfJoining, Employee.DateOfBirth, Employee.Designation, Employee.Salary);

        }

        private static void DisplayAll()
        {
            var ObjBLL = new EmployeeBLL();
            var EmployeesList = ObjBLL.GetAll();
            Console.WriteLine("Id\tName\tDOJ\t\tDOB\t\tDesignation\tSalary");
            Console.WriteLine("----------------------------------------------------------------");
            foreach(var Employee in EmployeesList)
            {
                Console.WriteLine("{0}\t{1}\t{2:d}\t{3:d}\t{4}\t{5}", Employee.Id, Employee.Name, Employee.DateOfJoining, Employee.DateOfBirth, Employee.Designation, Employee.Salary);
            }
        }

        private static void AddEmployee()
        {
            Console.WriteLine("Enter Id,Name,Date Of Joining, Date Of Birth, Designation");
            var EmployeeObj = new Employee();
            EmployeeObj.Id = Convert.ToInt32(Console.ReadLine());
            EmployeeObj.Name = Console.ReadLine();
            EmployeeObj.DateOfJoining = Convert.ToDateTime(Console.ReadLine());
            EmployeeObj.DateOfBirth = Convert.ToDateTime(Console.ReadLine());
            EmployeeObj.Designation = Console.ReadLine();

            var ObjBLL = new EmployeeBLL();
            var Added = ObjBLL.Add(EmployeeObj);
            if (Added)
                Console.WriteLine("Employee added");
            else
                Console.WriteLine("Failed to add employee");
        }

        static void PrintMenu()
        {
            Console.WriteLine("\n\n\n");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("\t\tEMPLOYEE MANAGEMENT SYSTEM");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("\t\t1.Add");
            Console.WriteLine("\t\t2.Display All");
            Console.WriteLine("\t\t3.Search");
            Console.WriteLine("\t\t4.Edit");
            Console.WriteLine("\t\t5.Delete");
            Console.WriteLine("\t\t6.Serialize to Binary");
            Console.WriteLine("\t\t7.DeSerialize from Binary");
            Console.WriteLine("\t\t8.Serialize to Soap");
            Console.WriteLine("\t\t9.DeSerialize from Soap");
            Console.WriteLine("\t\t10.Exit");
            Console.WriteLine("\n\nEnter your choice");
        }
    }
}
