﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using System.Data;


namespace OnlineRecruitmentSystem.DAL
{
    public class ApplicationTableDAL
    {
       
        public ApplicationTableDAL()
        {
            
        }
        public bool AddApplication(ApplicationTableEntities ApplicationTableEntitiesObj)
        {
            var IsAdded = false;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspInsertApplicationTable", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@JobId", DbType.Int32);
            P1.Value = ApplicationTableEntitiesObj.JobId;
            CommandObj.Parameters.Add(P1);

            var P2 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@JobSeekerId", DbType.Int32);
            P2.Value = ApplicationTableEntitiesObj.JobSeekerId;
            CommandObj.Parameters.Add(P2);


            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                IsAdded = NoOfRowsAffected == 1;
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsAdded;
        }
    }
}
