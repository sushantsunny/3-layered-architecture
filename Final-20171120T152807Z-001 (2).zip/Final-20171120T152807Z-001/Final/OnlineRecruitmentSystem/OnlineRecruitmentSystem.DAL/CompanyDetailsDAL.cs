﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using System.Data;
using System.Data.Common;



namespace OnlineRecruitmentSystem.DAL
{
    public class CompanyDetailsDAL
    {
        
        public CompanyDetailsDAL()
        {
           
        }

        public CompanyDetails FindByUserName(String UserName)
        {
            CompanyDetails Obj = null;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "[OnlineRecruitment].[uspRetreiveEmployerDetails]", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserName ", DbType.String);
            P1.Value = UserName;
            CommandObj.Parameters.Add(P1);

            try
            {
                DataTable TableObj = OnlineRecruitmentConnections.ExecuteReader(CommandObj);
                if (TableObj != null && TableObj.Rows.Count > 0)
                {
                    foreach (DataRow row in TableObj.Rows)
                    {
                        Obj = new CompanyDetails();
                        Obj.CompanyId = (int)row[0];
                        Obj.CompanyName = (string)row[1];
                        Obj.UserName = (string)row[2];
                        Obj.Description = (string)row[3];
                        Obj.CurrentStrength = (int)row[4];
                    }
                }
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error reading data", ex);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }

            return Obj;



        }
        public bool UpdateCompanyDetails(CompanyDetails Obj)
        {
            var IsUpdated = false;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspUpdateCompanyDetails", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@CompanyId", DbType.Int32);
            P1.Value = Obj.CompanyId;

            CommandObj.Parameters.Add(P1);

            var P2 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Description ", DbType.String);
            P2.Value = Obj.Description;
            P2.Size = 200;
            CommandObj.Parameters.Add(P2);

            var P3 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@CurrentStrength ", DbType.Int32);
            P3.Value = Obj.CurrentStrength;
            CommandObj.Parameters.Add(P3);




            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                IsUpdated = NoOfRowsAffected == 1;
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsUpdated;
        }
        public List<Job> GetJobbyCompany(int id)
        {
            List<Job> JobListObj = null;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspSelectJob", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@CompanyId", DbType.Int32);
            P1.Value = id;
            CommandObj.Parameters.Add(P1);

            try
            {
                DataTable TableObj = OnlineRecruitmentConnections.ExecuteReader(CommandObj);
                if (TableObj != null && TableObj.Rows.Count > 0)
                {
                    JobListObj = new List<Job>();
                    foreach (DataRow row in TableObj.Rows)
                    {
                        var JobObj = new Job();
                        JobObj.JobId = (int)row[0];
                        JobObj.CompanyId = (int)row[1];
                        JobObj.Designation = (string)row[2];
                        JobObj.NumberOfRequirement = (int)row[3];
                        JobObj.Location = (string)row[4];
                        JobObj.LastDateToApply = (DateTime)row[5];
                        JobListObj.Add(JobObj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error reading data", ex);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }

            return JobListObj;
        }
    }
}
