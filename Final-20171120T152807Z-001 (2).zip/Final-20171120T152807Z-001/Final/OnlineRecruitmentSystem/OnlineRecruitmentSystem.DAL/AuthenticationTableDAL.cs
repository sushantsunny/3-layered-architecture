﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;
using System.Configuration;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;

namespace OnlineRecruitmentSystem.DAL
{
   public class AuthenticationTableDAL
    {
        public  AuthenticationTableDAL()
        {

        }
        public static AuthenticationTableEntities Login(AuthenticationTableEntities Obj)
        {
            AuthenticationTableEntities newObj = new AuthenticationTableEntities();
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "[OnlineRecruitment].[uspLogin]", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserName", DbType.String);
            P1.Value = Obj.UserName;
            P1.Size = 25;
            CommandObj.Parameters.Add(P1);

            var P2 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Password", DbType.String);
            P2.Value = Obj.UserPassword;
            P2.Size = 10;
            CommandObj.Parameters.Add(P2);

            var P3 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserType", DbType.String, ParameterDirection.Output);
            P3.Value = Obj.UserType;
            P3.Size = 5;
            CommandObj.Parameters.Add(P3);

            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                newObj.UserType = P3.Value.ToString();
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return newObj;
        }
        public bool AddJobSeeker(JobSeekerDetail JobSeekerDetailObj,AuthenticationTableEntities AuthenticationTableEntitiesObj)
        {
            var IsAdded = false;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspInsertJobSeeker", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@JobSeekerName", DbType.String);
            P1.Value = JobSeekerDetailObj.JobSeekername;
            P1.Size = 40;
            CommandObj.Parameters.Add(P1);

            

            var P3 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@EmailId", DbType.String);
            P3.Value = JobSeekerDetailObj.EmailAddress;
            P3.Size = 30;
            CommandObj.Parameters.Add(P3);


            var P4 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@ContactNumber", DbType.String);
            P4.Value = JobSeekerDetailObj.ContactNumber;
            P4.Size = 10;
            CommandObj.Parameters.Add(P4);

            var P5 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Address", DbType.String);
            P5.Value = JobSeekerDetailObj.Address;
            P5.Size = 50;
            CommandObj.Parameters.Add(P5);

            var P6 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@DateOfBirth", DbType.DateTime);
            P6.Value = JobSeekerDetailObj.DateOfBirth;
            
            CommandObj.Parameters.Add(P6);

            var P7 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Experience", DbType.Decimal);
            P7.Value = JobSeekerDetailObj.Experience;
          
            CommandObj.Parameters.Add(P7);

            var P8 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Photo", DbType.String);
            P8.Value = JobSeekerDetailObj.ImagePath;
            P8.Size =100 ;
            CommandObj.Parameters.Add(P8);

            var P9 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Resume", DbType.String);
            P9.Value = JobSeekerDetailObj.ResumePath;
            P9.Size = 100;
            CommandObj.Parameters.Add(P9);


            var P10 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Usertype", DbType.String);
            P10.Value = AuthenticationTableEntitiesObj.UserType;
            P10.Size = 5;
            CommandObj.Parameters.Add(P10);

            var P11 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserName", DbType.String);
            P11.Value = AuthenticationTableEntitiesObj.UserName;
            P11.Size = 25;
            CommandObj.Parameters.Add(P11);

            var P12 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserPassword", DbType.String);
            P12.Value = AuthenticationTableEntitiesObj.UserPassword;
            P12.Size = 10;
            CommandObj.Parameters.Add(P12);
            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                IsAdded = NoOfRowsAffected == 2;
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsAdded;
        }


        public bool AddCompanyDetails(CompanyDetails CompanyDetailsObj, AuthenticationTableEntities AuthenticationTableEntitiesObj)
        {
            var IsAdded = false;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspInsertCompanyDetails", CommandType.StoredProcedure);

         


            var P3 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@CompanyName", DbType.String);
            P3.Value = CompanyDetailsObj.CompanyName;
            P3.Size = 25;
            CommandObj.Parameters.Add(P3);


            var P4 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Description", DbType.String);
            P4.Value = CompanyDetailsObj.Description;
            P4.Size = 200;
            CommandObj.Parameters.Add(P4);

            var P5 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@CurrentStrength", DbType.Int32);
            P5.Value = CompanyDetailsObj.CurrentStrength;
            CommandObj.Parameters.Add(P5);



            var P10 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Usertype", DbType.String);
            P10.Value = AuthenticationTableEntitiesObj.UserType;
            P10.Size = 5;
            CommandObj.Parameters.Add(P10);

            var P11 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserName", DbType.String);
            P11.Value = AuthenticationTableEntitiesObj.UserName;
            P11.Size = 25;
            CommandObj.Parameters.Add(P11);

            var P12 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserPassword", DbType.String);
            P12.Value = AuthenticationTableEntitiesObj.UserPassword;
            P12.Size = 10;
            CommandObj.Parameters.Add(P12);
            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                IsAdded = NoOfRowsAffected == 2;
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsAdded;
        }

    }
}
