﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace OnlineRecruitmentSystem.DAL
{
   static class OnlineRecruitmentConfigurations
    {
        static string _connectionString, _providerName;
        static OnlineRecruitmentConfigurations()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["OnlineRecruitment"].ConnectionString;
            _providerName = ConfigurationManager.ConnectionStrings["OnlineRecruitment"].ProviderName;
        }
        public static string ConnectionString { get { return _connectionString; } }
        public static string ProviderName { get { return _providerName; } }

    }
}
