﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using System.Data.Common;
using System.Data;


namespace OnlineRecruitmentSystem.DAL
{
    public class JobSeekerDetailsDAL
    {
        public JobSeekerDetailsDAL()
        {
            
        }
        public List<Job> GetJobs()
           {
            List<Job> JobObj = null;

            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspViewJob", CommandType.StoredProcedure);

            try
            {
                DataTable TableObj = OnlineRecruitmentConnections.ExecuteReader(CommandObj);
                if (TableObj != null && TableObj.Rows.Count > 0)
                {
                    JobObj = new List<Job>();
                    foreach (DataRow row in TableObj.Rows)
                    {
                        var JobListObj = new Job();
                        JobListObj.JobId = (int)row[0];
                        JobListObj.CompanyId = (int)row[1];
                        JobListObj.Designation = (string)row[2];
                        JobListObj.NumberOfRequirement = (int)row[3];
                        JobListObj.Location = (string)row[4];
                        JobListObj.LastDateToApply = (DateTime)row[5];
                        JobObj.Add(JobListObj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error reading data", ex);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }

            return JobObj;
        }
        public JobSeekerDetail GetDetailsByUserName(String UserName)
        {
            JobSeekerDetail JobSeekerDetailObj = null;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspRetreiveJobSeekerDetailsOnUserName", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@UserName", DbType.String);
            P1.Value = UserName;
            P1.Size = 30;
            CommandObj.Parameters.Add(P1);

            try
            {
                DataTable TableObj = OnlineRecruitmentConnections.ExecuteReader(CommandObj);
                if (TableObj != null && TableObj.Rows.Count > 0)
                {
                    foreach (DataRow row in TableObj.Rows)
                    {
                        JobSeekerDetailObj = new JobSeekerDetail();
                        JobSeekerDetailObj.JobSeekerId = (int)row[0];

                    }
                }
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error reading data", ex);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }

            return JobSeekerDetailObj;
        }
        public bool UpdateResume(JobSeekerDetail JobSeekerDetailObj)
        {
            var IsUpdated = false;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspUpdate_jobseeker_Details", CommandType.StoredProcedure);

            var P2 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@JobSeekerId", DbType.Int32);
            P2.Value = JobSeekerDetailObj.JobSeekerId;

            CommandObj.Parameters.Add(P2);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Resume", DbType.String);
            P1.Value = JobSeekerDetailObj.ResumePath;
            P1.Size = 100;
            CommandObj.Parameters.Add(P1);



            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                IsUpdated = NoOfRowsAffected == 1;
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsUpdated;
        }

        public JobSeekerDetail GetResume(int JobSeekerId)
        {
            JobSeekerDetail JobSeekerDetailObj = null;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspSelectResumeOnJobSeekerId", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@JobseekerId", DbType.Int32);
            P1.Value = JobSeekerId;
            CommandObj.Parameters.Add(P1);

            try
            {
                DataTable TableObj = OnlineRecruitmentConnections.ExecuteReader(CommandObj);
                if (TableObj != null && TableObj.Rows.Count > 0)
                {
                    foreach (DataRow row in TableObj.Rows)
                    {
                        JobSeekerDetailObj = new JobSeekerDetail();
                        JobSeekerDetailObj.ResumePath = (string)row[0];

                    }
                }
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error reading data", ex);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }

            return JobSeekerDetailObj;
        }
    }
  
}
