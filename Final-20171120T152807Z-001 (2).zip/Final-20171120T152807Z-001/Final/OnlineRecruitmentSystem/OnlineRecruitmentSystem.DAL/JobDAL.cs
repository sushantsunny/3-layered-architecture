﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using System.Data.Common;
using System.Data;


namespace OnlineRecruitmentSystem.DAL
{
   public class JobDAL
    {
        public List<Job> GetJobbyLocation(string location)
        {
           List <Job> JobListObj = null;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspSearchByLocation", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Location", DbType.String);
            P1.Value = location;
            CommandObj.Parameters.Add(P1);

            try
            {
                DataTable TableObj = OnlineRecruitmentConnections.ExecuteReader(CommandObj);
                if (TableObj != null && TableObj.Rows.Count > 0)
                {
                    JobListObj = new List<Job>();
                    foreach (DataRow row in TableObj.Rows)
                    {
                        var JobObj = new Job();
                        JobObj.JobId = (int)row[0];
                        JobObj.CompanyId = (int)row[1];
                        JobObj.Designation = (string)row[2];
                        JobObj.NumberOfRequirement = (int)row[3];
                        JobObj.Location = (string)row[4];
                        JobObj.LastDateToApply = (DateTime)row[5];
                        JobListObj.Add(JobObj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error reading data", ex);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }

            return JobListObj;
        }
        public List<Job> GetJobbyDesignation(string designation)
        {
            List<Job> JobListObj = null;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspSearchByDesignation", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Designation", DbType.String);
            P1.Value = designation;
            CommandObj.Parameters.Add(P1);

            try
            {
                DataTable TableObj = OnlineRecruitmentConnections.ExecuteReader(CommandObj);
                if (TableObj != null && TableObj.Rows.Count > 0)
                {
                    JobListObj = new List<Job>();
                    foreach (DataRow row in TableObj.Rows)
                    {
                        var JobObj = new Job();
                        JobObj.JobId = (int)row[0];
                        JobObj.CompanyId = (int)row[1];
                        JobObj.Designation = (string)row[2];
                        JobObj.NumberOfRequirement = (int)row[3];
                        JobObj.Location = (string)row[4];
                        JobObj.LastDateToApply = (DateTime)row[5];
                        JobListObj.Add(JobObj);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error reading data", ex);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }

            return JobListObj;
        }
        public bool AddJob(Job JobObj)
        {
            var IsAdded = false;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspInsertJobDetails", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Designation", DbType.String);
            P1.Value = JobObj.Designation;
            P1.Size = 25;
            CommandObj.Parameters.Add(P1);

            var P2 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Location", DbType.String);
            P2.Value = JobObj.Location;
            P2.Size = 25;
            CommandObj.Parameters.Add(P2);



            var P3 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@LastDateToApply", DbType.Date);
            P3.Value = JobObj.LastDateToApply;
            CommandObj.Parameters.Add(P3);



            var P4 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@NumberOfRequirement", DbType.Double);
            P4.Value = JobObj.NumberOfRequirement;
            CommandObj.Parameters.Add(P4);

            var P5 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@CompanyId", DbType.Int32);
            P5.Value = JobObj.CompanyId;
            CommandObj.Parameters.Add(P5);



            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                IsAdded = NoOfRowsAffected == 1;
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsAdded;
        }
        public bool UpdateJob(Job JobObj)
        {
            var IsUpdated = false;
            var ConnectionObj = OnlineRecruitmentConnections.CreateConnection();
            var CommandObj = OnlineRecruitmentConnections.CreateCommand(ConnectionObj, "OnlineRecruitment.uspUpdateJobDetails", CommandType.StoredProcedure);

            var P1 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Designation", DbType.String);
            P1.Value = JobObj.Designation;
            P1.Size = 25;
            CommandObj.Parameters.Add(P1);

            var P2 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@Location", DbType.String);
            P2.Value = JobObj.Location;
            P2.Size = 25;
            CommandObj.Parameters.Add(P2);



            var P3 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@LastDateToApply", DbType.Date);
            P3.Value = JobObj.LastDateToApply;
            CommandObj.Parameters.Add(P3);



            var P4 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@NumberOfRequirement", DbType.Double);
            P4.Value = JobObj.NumberOfRequirement;
            CommandObj.Parameters.Add(P4);

            var P5 = OnlineRecruitmentConnections.CreateParameter(CommandObj, "@JobId", DbType.Int32);
            P5.Value = JobObj.JobId;
            CommandObj.Parameters.Add(P5);



            try
            {
                var NoOfRowsAffected = OnlineRecruitmentConnections.ExecuteNonQuery(CommandObj);
                IsUpdated = NoOfRowsAffected == 1;
            }
            catch (DbException ex)
            {
                throw new OnlineRecruitmentDetailsExceptions(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsUpdated;
        }
    }
          
    }

