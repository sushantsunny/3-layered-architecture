﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OnlineRecruitmentSystem.BLL;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using Microsoft.Win32;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for AfterRegistrationCompany.xaml
    /// </summary>
    public partial class AfterRegistrationCompany : Page
    {
        public AfterRegistrationCompany()
        {
            InitializeComponent();
        }
        JobSeekerDetail JobSeekerDetailObj = new JobSeekerDetail();
        AuthenticationTableEntities AuthenticationTableObj = new AuthenticationTableEntities();
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {

            
            try
            {
                JobSeekerDetailObj.JobSeekername = txtJobName.Text;
           
            JobSeekerDetailObj.DateOfBirth = Convert.ToDateTime(dtpDateOfBirth.Text);
                

                JobSeekerDetailObj.EmailAddress = txtJobEmail.Text;
                JobSeekerDetailObj.ContactNumber = txtContact.Text;
                JobSeekerDetailObj.Address = txtAddress.Text;
              JobSeekerDetailObj.Experience = Convert.ToDecimal(txtExperience.Text);
                JobSeekerDetailObj.Username = txtUserName.Text;
               
                AuthenticationTableObj.UserType = "j";
                AuthenticationTableObj.UserName = txtUserName.Text;
                AuthenticationTableObj.UserPassword = txtPassword.Text;
                var AuthenticationTableBLLObj = new AuthenticationTableBLL();
                var IsAdded = AuthenticationTableBLLObj.Add(JobSeekerDetailObj, AuthenticationTableObj);
                
                if (IsAdded)
            {
                MessageBox.Show("Job Seeker Details added", "Information");
                //  FillDataGridView();
            }
            else
                MessageBox.Show("Job Seeker Details not added", "Warning");
            }

            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
           
        }

        private void btnResume_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = "PDF Files (*.pdf)|*.pdf";
            dialog.DefaultExt = "pdf";
            dialog.AddExtension = true;
            if (dialog.ShowDialog().GetValueOrDefault() == true)
            {
                using (var fs = new System.IO.FileStream(dialog.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                {
                    using (var sr = new System.IO.BinaryReader(fs))
                    {
                       
                        var fs1 = new System.IO.FileStream("..\\..\\Resume\\"+dialog.SafeFileName , System.IO.FileMode.Create, System.IO.FileAccess.Write);
                        var sw = new System.IO.BinaryWriter(fs1);

                        sw.Write(sr.ReadBytes((int)fs.Length - 1));

                        sw.Close();
                        fs1.Close();
                        sr.Close();
                        fs.Close();
                        JobSeekerDetailObj.ResumePath = "Resume\\" + dialog.SafeFileName ;
                    }
                }
            }
        }

        private void btnPhoto_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = "JPG Files (*.jpg)|*.jpg";
            dialog.DefaultExt = "jpg";
            dialog.AddExtension = true;

            if (dialog.ShowDialog().GetValueOrDefault() == true)
            {
                using (var fs = new System.IO.FileStream(dialog.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                {
                    using (var sr = new System.IO.BinaryReader(fs))
                    {
                       
                        var fs1 = new System.IO.FileStream("..\\..\\Photos\\" + dialog.SafeFileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
                        var sw = new System.IO.BinaryWriter(fs1);

                        sw.Write(sr.ReadBytes((int)fs.Length - 1));

                        sw.Close();
                        fs1.Close();
                        sr.Close();
                        fs.Close();
                        JobSeekerDetailObj.ImagePath = "Photos\\" + dialog.SafeFileName;
                    }
                }
            }
        }

    }
}
