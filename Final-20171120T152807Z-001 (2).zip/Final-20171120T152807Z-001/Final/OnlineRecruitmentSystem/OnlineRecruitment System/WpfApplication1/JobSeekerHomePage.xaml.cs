﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using OnlineRecruitmentSystem.BLL;
using Microsoft.Win32;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for JobSeekerHomePage.xaml
    /// </summary>
    public partial class JobSeekerHomePage : Page
    {
        public string UserName { get; set; }
        public JobSeekerHomePage(string username)
        {

            InitializeComponent();
            this.UserName = username;
            var JobSeekerDetailsBLLObj = new JobSeekerDetailsBLL();

            var JobSeekerDetailsObj = JobSeekerDetailsBLLObj.FindByUserName(UserName);
            txtId.Text = JobSeekerDetailsObj.JobSeekerId.ToString();
        }
        JobSeekerDetail JobSeekerDetailObj = new JobSeekerDetail();
        AuthenticationTableEntities AuthenticationTableObj = new AuthenticationTableEntities();


        private void FillDataGridViewLocation()
        {
            try
            {
                var JobBLLObj = new JobBLL();
                var Location = txtValue.Text;
                var SearchJobListLocation = JobBLLObj.FindByLocation(Location);
                dgSearch.ItemsSource = SearchJobListLocation.ToList();
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }
        private void FillDataGridViewDesignation()
        {
            try
            {
                var JobBLLObj = new JobBLL();
                var Designation = txtValue.Text;
                var SearchJobListDesignation = JobBLLObj.FindByDesignation(Designation);
                dgSearch.ItemsSource = SearchJobListDesignation.ToList();
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            var Search = lbSearch.SelectedItem as ListBoxItem;
            if (Search.Content.ToString() == "Location")
            {
                FillDataGridViewLocation();
            }
            else if (Search.Content.ToString() == "Designation")
            {
                FillDataGridViewDesignation();
            }

        }

        private void btnViewJob_Click(object sender, RoutedEventArgs e)
        {
            FillDataGridViewJobs();
        }
        private void FillDataGridViewJobs()
        {
            try
            {
                var JobBLLObj = new JobSeekerDetailsBLL();
                var JobList = JobBLLObj.GetAll();
                dgSearch.ItemsSource = JobList;
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnApply_Click(object sender, RoutedEventArgs e)
        {
            var j = dgSearch.SelectedItem as Job;

            //MessageBox.Show(j.JobId.ToString());
            var ApplicationTableEntitiesObj = new ApplicationTableEntities();
            try
            {
                ApplicationTableEntitiesObj.JobId = j.JobId;
                ApplicationTableEntitiesObj.JobSeekerId = Convert.ToInt32(txtId.Text);

                var ApplicationTableBLLObj = new ApplicationTableBLL();
                var IsAdded = ApplicationTableBLLObj.Add(ApplicationTableEntitiesObj);
                if (IsAdded)
                {
                    MessageBox.Show("Applied for Job Successfully");
                    //FillDataGridView();
                }
                else
                    MessageBox.Show("Unable to send ur job application", "Warning");
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

        }

        private void btnDownloadResume_Click(object sender, RoutedEventArgs e)
        {
            int JobSeekerId = Convert.ToInt32(txtId.Text);
            var JobSeekerDetailsBLLObj = new JobSeekerDetailsBLL();
            var JobSeekerDetailsObj = JobSeekerDetailsBLLObj.FindResume(JobSeekerId);
            var dialog = new SaveFileDialog();
            dialog.Filter = "PDF Files (*.pdf)|*.pdf";
            dialog.DefaultExt = "pdf";
            dialog.AddExtension = true;
            if (dialog.ShowDialog().GetValueOrDefault() == true)
            {
                using (var fs = new System.IO.FileStream("..\\..\\"+JobSeekerDetailsObj.ResumePath, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                {
                    using (var sr = new System.IO.BinaryReader(fs))
                    {

                        var fs1 = new System.IO.FileStream(dialog.FileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
                        var sw = new System.IO.BinaryWriter(fs1);

                        sw.Write(sr.ReadBytes((int)fs.Length - 1));

                        sw.Close();
                        fs1.Close();
                        sr.Close();
                        fs.Close();
                    }
                }
            }
        }


        private void btnUpdateResume_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = "PDF Files (*.pdf)|*.pdf";
            dialog.DefaultExt = "pdf";
            dialog.AddExtension = true;
            if (dialog.ShowDialog().GetValueOrDefault() == true)
            {
                using (var fs = new System.IO.FileStream(dialog.FileName, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                {
                    using (var sr = new System.IO.BinaryReader(fs))
                    {

                        var fs1 = new System.IO.FileStream("..\\..\\Resume\\" + dialog.SafeFileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
                        var sw = new System.IO.BinaryWriter(fs1);

                        sw.Write(sr.ReadBytes((int)fs.Length - 1));

                        sw.Close();
                        fs1.Close();
                        sr.Close();
                        fs.Close();
                        JobSeekerDetailObj.ResumePath = "Resume\\" + dialog.SafeFileName;
                    }
                }

                try
                {
                    JobSeekerDetailObj.JobSeekerId = Convert.ToInt32(txtId.Text);
                    JobSeekerDetailObj.ResumePath = "Resume\\" + dialog.SafeFileName;


                    var JobSeekerDetailsBLLObj = new JobSeekerDetailsBLL();
                    var IsUpdated = JobSeekerDetailsBLLObj.UpdateResume(JobSeekerDetailObj);
                    if (IsUpdated)
                    {
                        MessageBox.Show("Resume updated", "Information");
                        //FillDataGridView();
                    }
                    else
                        MessageBox.Show("Resume not updated", "Warning");
                }
                catch (FormatException ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }
                catch (OnlineRecruitmentDetailsExceptions ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }

            }
        }
    }  
}
