﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OnlineRecruitmentSystem.BLL;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
        }

       

      

        private void btnLogIn_Click_1(object sender, RoutedEventArgs e)
        {
            AuthenticationTableEntities obj = new AuthenticationTableEntities();

            try
            {

                obj.UserName = txtId.Text;
                obj.UserPassword = txtId2.Password;
                var BLLobj = new AuthenticationTableBLL();
                var type = BLLobj.Login(obj);


                if (type.UserType == "c")
                {
                    CompanyHomePage cc = new CompanyHomePage(txtId.Text);
                    
                    this.NavigationService.Navigate(cc);
                }
                else if (type.UserType == "j")
                {
                    JobSeekerHomePage jj = new JobSeekerHomePage(txtId.Text);

                    this.NavigationService.Navigate(jj);
                }
                else
                    MessageBox.Show("Please Enter Proper Credentials");




            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnRegister_Click_1(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Page2.xaml", UriKind.Relative));
        }
    }
}
