﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OnlineRecruitmentSystem.BLL;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for AfterRegistrationJobseeker.xaml
    /// </summary>
    public partial class AfterRegistrationJobseeker : Page
    {
        public AfterRegistrationJobseeker()
        {
            InitializeComponent();
        }

        private void btnRegisterCompany_Click(object sender, RoutedEventArgs e)
        {
            var CompanyDetailsObj= new CompanyDetails();
            var AuthenticationTableEntitiesObj = new AuthenticationTableEntities();
            try
            {
                CompanyDetailsObj.CompanyName = txtCompanyName.Text;
                CompanyDetailsObj.Description = txtDescription.Text;
                CompanyDetailsObj.CurrentStrength = Convert.ToInt32(txtCurrentStrength.Text);
                AuthenticationTableEntitiesObj.UserName = (txtUserName.Text);
                AuthenticationTableEntitiesObj.UserPassword=txtPassword.Password ;
                AuthenticationTableEntitiesObj.UserType = "c";

                var AuthenticationTableBLLObj = new AuthenticationTableBLL();
                var IsAdded = AuthenticationTableBLLObj.AddCompany(CompanyDetailsObj, AuthenticationTableEntitiesObj);
                
                if (IsAdded)
                {
                    MessageBox.Show("Company Details added", "Information");
                    //  FillDataGridView();
                }
                else
                    MessageBox.Show("Company Details not added", "Warning");
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
           

        }
    }
}
