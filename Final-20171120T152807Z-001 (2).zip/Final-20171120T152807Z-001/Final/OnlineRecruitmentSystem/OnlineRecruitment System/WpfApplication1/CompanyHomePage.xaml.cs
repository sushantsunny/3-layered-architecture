﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OnlineRecruitmentSystem.Exceptions;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.BLL;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for CompanyHomePage.xaml
    /// </summary>
    public partial class CompanyHomePage : Page
    {
        public CompanyHomePage()
        {
            InitializeComponent();
        }
        public string UserName { get; set; }
        public CompanyHomePage(string username)
        {
            InitializeComponent();
            this.UserName = username;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/AfterLoginCompanyPostJobs.xaml", UriKind.Relative));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            txtCompanyStrength.IsReadOnly = false;
            txtCompanyDescription.IsReadOnly = false;
            btnSave.Visibility = Visibility.Visible;
            btnEdit.Visibility = Visibility.Hidden;

            //this.NavigationService.Navigate(new Uri("/AfterLoginCompanyEditProfile.xaml", UriKind.Relative));
        }

        private void btnPostJob_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/AfterLoginCompanyPostJobs.xaml", UriKind.Relative));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                var CompanyBLLObj = new CompanyDetailsBLL();
                var username = this.UserName;
                var CompanyObj = CompanyBLLObj.FindByUserName(username);
                txtCompanyId.Text = CompanyObj.CompanyId.ToString();
                txtCompanyName.Text = CompanyObj.CompanyName;
                txtCompanyDescription.Text = CompanyObj.Description;
                txtCompanyStrength.Text = CompanyObj.CurrentStrength.ToString();

            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var Obj = new CompanyDetails();
            try
            {
                Obj.CompanyId = Convert.ToInt32(txtCompanyId.Text);
                Obj.CompanyName = txtCompanyName.Text;
                Obj.Description = txtCompanyDescription.Text;
                Obj.CurrentStrength = Convert.ToInt32(txtCompanyStrength.Text);

                var BLLObj = new CompanyDetailsBLL();
                var IsUpdated = BLLObj.Update(Obj);
                if (IsUpdated)
                {
                    MessageBox.Show("Details Updated");
                    //this.NavigationService.Navigate(new Uri("/AfterLoginCompany.xaml", UriKind.Relative));

                }
                else
                    MessageBox.Show("Unable to update details");
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                var CompanyBLLObj = new CompanyDetailsBLL();
                var username = this.UserName;
                var CompanyObj = CompanyBLLObj.FindByUserName(username);
                txtCompanyId.Text = CompanyObj.CompanyId.ToString();
                txtCompanyName.Text = CompanyObj.CompanyName;
                txtCompanyDescription.Text = CompanyObj.Description;
                txtCompanyStrength.Text = CompanyObj.CurrentStrength.ToString();

            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

        }

        private void btnPost_Click(object sender, RoutedEventArgs e)
        {

            var CompanyObj = new Job();

            try
            {
                CompanyObj.CompanyId = Convert.ToInt32(txtCompanyId.Text);
                CompanyObj.Designation = txtDesignation.Text;

                CompanyObj.LastDateToApply = Convert.ToDateTime(dtpLastDateToApply.Text);


                CompanyObj.Location = txtLocation.Text; ;
                CompanyObj.NumberOfRequirement = Convert.ToInt32(txtNoOfRequirement.Text);

                var JobBLLObj = new JobBLL();
                var IsAdded = JobBLLObj.Add(CompanyObj);

                if (IsAdded)
                {
                    MessageBox.Show("Company Post Job Details added", "Information");
                    //  FillDataGridView();
                }
                else
                    MessageBox.Show("Company Post Job  Details not added", "Warning");
            }

            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }


        }
        private void FillDataGridView()
        {
            try
            {
                var JobBLLObj = new CompanyDetailsBLL();
                var id = Convert.ToInt32(txtCompanyId.Text);
                var SearchJobListDesignation = JobBLLObj.FindByCompany(id);
                dgJob.ItemsSource = SearchJobListDesignation.ToList();
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void Grid_Loaded_1(object sender, RoutedEventArgs e)
        {
            FillDataGridView();
        }

        private void btnSaveJob_Click(object sender, RoutedEventArgs e)
        {
            var JobObj = new Job();
            try
            {
               
                JobObj.JobId = id;
                JobObj.Designation = txtDesignation.Text;
                JobObj.Location=txtLocation.Text;
                JobObj.NumberOfRequirement = Convert.ToInt32(txtNoOfRequirement.Text);
                JobObj.LastDateToApply = Convert.ToDateTime(dtpLastDateToApply.Text);

                var JobBLLObj = new JobBLL();
                var IsUpdated = JobBLLObj.UpdateJob(JobObj);
                if (IsUpdated)
                {
                    MessageBox.Show("Job Details updated", "Information");
                    FillDataGridView();
                }
                else
                    MessageBox.Show("Job Details not updated", "Warning");
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

        }

        int id;

        private void dgJob_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(dgJob.SelectedIndex>0)
            {
                var JobObj = dgJob.SelectedItem as Job;
                id = JobObj.JobId;
                txtDesignation.Text = JobObj.Designation;
                txtNoOfRequirement.Text = JobObj.NumberOfRequirement.ToString();
                txtLocation.Text = JobObj.Location;
                dtpLastDateToApply.Text = JobObj.LastDateToApply.ToShortDateString();
            }
        }
    }
    
}
