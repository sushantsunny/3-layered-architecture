﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineRecruitmentSystem.Entities
{
   public class ApplicationTableEntities
    {
        public string ApplicationNumber { get; set; }
        public int JobSeekerId { get; set; }
        public int JobId { get; set; }
        public ApplicationTableEntities()
        {

        }

    }
}
