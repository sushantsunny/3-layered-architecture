﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineRecruitmentSystem.Entities
{
   public class JobSeekerDetail
    {
       

        public int JobSeekerId { get; set; }
        public string JobSeekername { get; set; }
        public string Username { get; set; }
        public string EmailAddress { get; set; }
        public string ContactNumber { get; set; }
        public string Address { get; set; }
        public DateTime DateOfBirth { get; set; }
        public decimal Experience { get; set; }
       // public string Photo { get; set; }
        //public string Resume { get; set; }
        public string ImagePath { get; set; }
        public string ResumePath { get; set; }
        public JobSeekerDetail()
        {

        }
    }
}
