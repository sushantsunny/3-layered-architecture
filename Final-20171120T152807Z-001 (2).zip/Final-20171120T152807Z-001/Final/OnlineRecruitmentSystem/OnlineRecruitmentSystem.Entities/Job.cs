﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineRecruitmentSystem.Entities
{
    
    public class Job
    {
        public int JobId { get; set; }
        public int CompanyId { get; set; }
        public string Location { get; set; }
       
        public DateTime LastDateToApply { get; set; }
        public string Designation { get; set; }
        public double NumberOfRequirement { get; set; }
        public Job()
        {

        }

    }
}
