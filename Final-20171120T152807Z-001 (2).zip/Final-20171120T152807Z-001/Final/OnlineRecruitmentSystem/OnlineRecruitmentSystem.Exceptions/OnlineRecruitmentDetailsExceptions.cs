﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineRecruitmentSystem.Exceptions
{
  public  class OnlineRecruitmentDetailsExceptions:ApplicationException
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public OnlineRecruitmentDetailsExceptions() : base()
        {

        }
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="message">Message to initialize</param>
        public OnlineRecruitmentDetailsExceptions(string message) : base(message)
        {

        }
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="message">Exception message</param>
        /// <param name="innerException">Inner exception if any</param>
        public OnlineRecruitmentDetailsExceptions(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
