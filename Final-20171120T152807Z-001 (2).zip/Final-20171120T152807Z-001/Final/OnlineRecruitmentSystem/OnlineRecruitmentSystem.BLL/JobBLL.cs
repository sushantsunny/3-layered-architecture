﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using OnlineRecruitmentSystem.DAL;
using System.Text.RegularExpressions;

namespace OnlineRecruitmentSystem.BLL
{
    public class JobBLL
    {
        JobDAL JobOperationsDAL;
        public JobBLL()
        {
            JobOperationsDAL = new JobDAL();
        }
        private bool ValidateJob(Job JobObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[a-zA-Z\\s]{3,25}$");
            //if (JobObj.JobId < 1000)
            //{
            //    IsValid = false;
            //    ErrorMessages.AppendLine("JobId should be greater than 999");
            //}
            //if (JobObj.CompanyId < 1000)
            //{
            //    IsValid = false;
            //    ErrorMessages.AppendLine("CompanyId should be greater than 999");
            //}
            if (JobObj.NumberOfRequirement <= 0)
            {
                IsValid = false;
                ErrorMessages.AppendLine("JobId should be greater than 0");
            }
            if (string.IsNullOrEmpty(JobObj.Location) || !RegExObj.IsMatch(JobObj.Location))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Location should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only single space is allowed");
            }
            if (string.IsNullOrEmpty(JobObj.Designation) || !RegExObj.IsMatch(JobObj.Designation))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Designation should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only single space is allowed");
            }
            if (JobObj.LastDateToApply.Date < DateTime.Now.Date)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Error Date");
            }


            if (IsValid == false)
            {
                throw new OnlineRecruitmentDetailsExceptions(ErrorMessages.ToString());
            }

            return IsValid;
        }

     

        public List<Job> FindByLocation(string location)
        {
            var JobList = new List<Job>();
            try
            {
               

                var ObjDAL = new JobDAL();
                JobList = ObjDAL.GetJobbyLocation(location);

                if (JobList == null)
                    throw new OnlineRecruitmentDetailsExceptions("No job exists according to filter.");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error searching Job", ex);
            }
            return JobList;
        }


        public List<Job> FindByDesignation(string designation)
        {
            var JobList = new List<Job>();
            try
            {


                var ObjDAL = new JobDAL();
                JobList = ObjDAL.GetJobbyDesignation(designation);

                if (JobList == null)
                    throw new OnlineRecruitmentDetailsExceptions("No job exists according to filter.");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error searching Job", ex);
            }
            return JobList;
        }
        public bool Add(Job JobObj)

        {
            JobOperationsDAL = new JobDAL();
            var IsSaved = false;
            try
            {
                if (ValidateJob(JobObj)==true)
                {

                    IsSaved = JobOperationsDAL.AddJob(JobObj);
                }
            }

            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsSaved;
        }
        public bool UpdateJob(Job JobObj)
        {
            var IsUpdated = false;
            try
            {
                if (JobObj == null)
                    throw new OnlineRecruitmentDetailsExceptions("Job required for update");
                var ObjDAL = new JobDAL();

                IsUpdated = ObjDAL.UpdateJob(JobObj);
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error editing Job details", ex);
            }
            return IsUpdated;
        }

    }
}

       