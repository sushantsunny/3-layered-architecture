﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineRecruitmentSystem.DAL;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using System.Text.RegularExpressions;

namespace OnlineRecruitmentSystem.BLL
{
    public class ApplicationTableBLL
    {
        private bool Validate(ApplicationTableEntities ApplicationTableEntitiesObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[0-9]{6,6}$");
            if (ApplicationTableEntitiesObj.JobId <= 0)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Job Id should be greater than 0");
            }

            if (ApplicationTableEntitiesObj.JobSeekerId <= 0)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Job Seeker Id should be greater than 0");
            }


            //if (string.IsNullOrEmpty(ApplicationTableEntitiesObj.ApplicationNumber) || !RegExObj.IsMatch(ApplicationTableEntitiesObj.ApplicationNumber))
            //{
            //    IsValid = false;
            //    ErrorMessages.AppendLine("Application Number should not be blank");
            //    ErrorMessages.AppendLine("Maximum 6 Numbers are allowed");
            //}

            if (IsValid == false)
            {
                throw new OnlineRecruitmentDetailsExceptions(ErrorMessages.ToString());
            }

            return IsValid;
        }
        public bool Add(ApplicationTableEntities ApplicationTableEntitiesObj)
        {
            var IsSaved = false;
            try
            {
                if (Validate(ApplicationTableEntitiesObj))
                {

                    ApplicationTableDAL obj = new ApplicationTableDAL();
                    IsSaved = obj.AddApplication(ApplicationTableEntitiesObj);
                }
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return IsSaved;
        }

    }
}