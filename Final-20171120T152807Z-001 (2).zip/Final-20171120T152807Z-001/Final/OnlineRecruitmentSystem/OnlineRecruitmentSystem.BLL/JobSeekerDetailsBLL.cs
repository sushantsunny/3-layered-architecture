﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using OnlineRecruitmentSystem.DAL;

namespace OnlineRecruitmentSystem.BLL
{
   public class JobSeekerDetailsBLL
    {
        private bool ValidateJobSeeker(JobSeekerDetail jobSeekerObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[a-zA-Z\\s\\s]{3,40}$");
            var UserNameRegex = new Regex("^[a-zA-z0-9_]{3,25}$");
            var EmailRegex = new Regex("^[a-zA-z0-9_]{3,17}@[a-zA-z]{3,8}\\.(com|in|org|co.in)$");
            var ContactNoRegex = new Regex("^[7-9]{1}[0-9]{9}$");
            var AddressRegex = new Regex("^[a-zA-Z0-9\\s{7}]{3,50}");
            if (jobSeekerObj.JobSeekerId <= 1000)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Job Seeker Id should be greater than 999");
            }
            if (string.IsNullOrEmpty(jobSeekerObj.JobSeekername) || !RegExObj.IsMatch(jobSeekerObj.JobSeekername))
            {
                IsValid = false;
                ErrorMessages.AppendLine("JobSeeker Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only 2 number of space are allowed");
            }
            if (string.IsNullOrEmpty(jobSeekerObj.Username) || !UserNameRegex.IsMatch(jobSeekerObj.Username))
            {
                IsValid = false;
                ErrorMessages.AppendLine("User Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only underscore is allowed");
            }
            if (string.IsNullOrEmpty(jobSeekerObj.EmailAddress) || !EmailRegex.IsMatch(jobSeekerObj.EmailAddress))
            {
                IsValid = false;
                ErrorMessages.AppendLine("EmailAddress should not be blank");
                ErrorMessages.AppendLine("Maximum 30 characters are allowed and only .com, .in .org and .co.in are allowed");
            }

            if (string.IsNullOrEmpty(jobSeekerObj.ContactNumber) || !ContactNoRegex.IsMatch(jobSeekerObj.ContactNumber))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Contact Number should not be blank");
                ErrorMessages.AppendLine("Maximum 10 dogits are allowed and first digit should be 7,8 or 9");
            }
            if (string.IsNullOrEmpty(jobSeekerObj.Address) || !AddressRegex.IsMatch(jobSeekerObj.Address))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Address should not be blank");
                ErrorMessages.AppendLine("Maximum 50 characters are allowed.");
            }
          
           
            if (IsValid == false)
            {
                throw new OnlineRecruitmentDetailsExceptions(ErrorMessages.ToString());
            }

            return IsValid;
        }
        public List<Job> GetAll()
        {
            var JobList = new List<Job>();
            try
            {
                var ObjDAL = new JobSeekerDetailsDAL();
                JobList = ObjDAL.GetJobs();
                if (JobList == null || JobList.Count == 0)
                    throw new OnlineRecruitmentDetailsExceptions("Jobs not found");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return JobList;
        }
        public JobSeekerDetail FindByUserName(String UserName)
        {
            JobSeekerDetail JobSeekerDetailObj = null;
            try
            {
                if (UserName == null)
                    throw new OnlineRecruitmentDetailsExceptions("User name should not be null");

                var ObjDAL = new JobSeekerDetailsDAL();
                JobSeekerDetailObj = ObjDAL.GetDetailsByUserName(UserName);

                if (JobSeekerDetailObj == null)
                    throw new OnlineRecruitmentDetailsExceptions("No such Job Seeker exists");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error searching Details of Job Seeker", ex);
            }
            return JobSeekerDetailObj;
        }
        public bool UpdateResume(JobSeekerDetail JobSeekerDetailObj)
        {
            var IsUpdated = false;
            try
            {
                if (JobSeekerDetailObj == null)
                    throw new OnlineRecruitmentDetailsExceptions("Resume required for update");
                var ObjDAL = new JobSeekerDetailsDAL();

                IsUpdated = ObjDAL.UpdateResume(JobSeekerDetailObj);
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error editing Resume details", ex);
            }
            return IsUpdated;
        }

        public JobSeekerDetail FindResume(int JobSeekerId)
        {
            JobSeekerDetail JobSeekerDetailObj = null;
            try
            {
                if (JobSeekerId <= 0)
                    throw new OnlineRecruitmentDetailsExceptions("JobSeeker Id should be greater than 0");

                var ObjDAL = new JobSeekerDetailsDAL();
                JobSeekerDetailObj = ObjDAL.GetResume(JobSeekerId);

                if (JobSeekerDetailObj == null)
                    throw new OnlineRecruitmentDetailsExceptions("No such Resume exists");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error searching Resume", ex);
            }
            return JobSeekerDetailObj;
        }

    }
}
