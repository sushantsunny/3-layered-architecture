﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using OnlineRecruitmentSystem.DAL;
using System.Text.RegularExpressions;




namespace OnlineRecruitmentSystem.BLL
{
    public class CompanyDetailsBLL
    {
        private bool ValidateCompanyDetails(CompanyDetails CompanyDetailsObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[a-zA-Z\\s]{3,25}$");
            var UserNameRegex = new Regex("^[a-zA-z0-9_]{3,25}");
            var DescriptionRegex = new Regex("^[a-zA-Z0-9.]{10,200}");
           
            if (CompanyDetailsObj.CompanyId <= 1000)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Company Id should be greater than 999");
            }
            if (string.IsNullOrEmpty(CompanyDetailsObj.CompanyName) || !RegExObj.IsMatch(CompanyDetailsObj.CompanyName))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Company Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only single space is allowed");
            }
            if (string.IsNullOrEmpty(CompanyDetailsObj.UserName) || !RegExObj.IsMatch(CompanyDetailsObj.UserName))
            {
                IsValid = false;
                ErrorMessages.AppendLine("User Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only underscore is allowed");
            }
            if (string.IsNullOrEmpty(CompanyDetailsObj.Description) || !RegExObj.IsMatch(CompanyDetailsObj.Description))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Company Description should not be blank");
                ErrorMessages.AppendLine("Maximum 200 characters is allowed in Description");
            }
            if (CompanyDetailsObj.CurrentStrength <= 0)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Company Strength should be greater than 0 and numeric.");
            }


            if (IsValid == false)
            {
                throw new OnlineRecruitmentDetailsExceptions(ErrorMessages.ToString());
            }

            return IsValid;
        }
        public CompanyDetails FindByUserName(String UserName)
        {
            CompanyDetails Obj = null;
            try
            {
                if (UserName == null)
                    throw new OnlineRecruitmentDetailsExceptions("Please Enter Valid UserName!");

                var ObjDAL = new CompanyDetailsDAL();
                Obj = ObjDAL.FindByUserName(UserName);

                if (Obj == null)
                    throw new OnlineRecruitmentDetailsExceptions("No such Company exists");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error searching Company", ex);
            }
            return Obj;
        }
        public bool Update(CompanyDetails Obj)
        {
            var IsUpdated = false;
            try
            {
                if (Obj == null)
                    throw new OnlineRecruitmentDetailsExceptions("Company details required for update");
                var ObjDAL = new CompanyDetailsDAL();

                IsUpdated = ObjDAL.UpdateCompanyDetails(Obj);
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error editing Company details");
            }
            return IsUpdated;
        }
        public List<Job> FindByCompany(int id)
        {
            var JobList = new List<Job>();
            try
            {


                var ObjDAL = new CompanyDetailsDAL();
                JobList = ObjDAL.GetJobbyCompany(id);

                if (JobList == null)
                    throw new OnlineRecruitmentDetailsExceptions("No job exists according to filter.");
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Error searching Job", ex);
            }
            return JobList;
        }

    }
}
