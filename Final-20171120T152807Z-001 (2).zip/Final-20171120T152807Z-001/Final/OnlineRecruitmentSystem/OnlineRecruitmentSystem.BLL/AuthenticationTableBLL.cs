﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineRecruitmentSystem.DAL;
using OnlineRecruitmentSystem.Entities;
using OnlineRecruitmentSystem.Exceptions;
using System.Text.RegularExpressions;

namespace OnlineRecruitmentSystem.BLL
{
   
    public class AuthenticationTableBLL
    {
        private bool Validate(AuthenticationTableEntities AuthenticationTableEntitiesObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[J,C,j,c]{1,1}$");
            var UserNameRegex = new Regex("^[a-zA-z0-9_]{3,25}$");
            var RegExObjPass = new Regex("^[A-za-z0-9]{6,10}");
           
            if (string.IsNullOrEmpty(AuthenticationTableEntitiesObj.UserType) || !RegExObj.IsMatch(AuthenticationTableEntitiesObj.UserType))
            {
                IsValid = false;

                ErrorMessages.AppendLine("Only J or C is allowed");
            }
            if (string.IsNullOrEmpty(AuthenticationTableEntitiesObj.UserName) || !UserNameRegex.IsMatch(AuthenticationTableEntitiesObj.UserName))
            {
                IsValid = false;
                ErrorMessages.AppendLine("User Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only underscore is allowed");
            }
            if (string.IsNullOrEmpty(AuthenticationTableEntitiesObj.UserPassword) || !RegExObjPass.IsMatch(AuthenticationTableEntitiesObj.UserPassword))
            {
                IsValid = false;

                ErrorMessages.AppendLine("In Password Max 10 and Min 6 characters are allowed. Only characters and Digits allowed");
            }
          

            if (IsValid == false)
            {
                throw new OnlineRecruitmentDetailsExceptions(ErrorMessages.ToString());
            }
           

            return IsValid;
        }
        private bool ValidateJobSeeker(JobSeekerDetail jobSeekerObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[a-zA-Z\\s\\s]{3,40}$");
           // var UserNameRegex = new Regex("^[a-zA-z0-9_]{3,25}$");
            var EmailRegex = new Regex("^[a-zA-z0-9_]{3,17}@[a-zA-z]{3,8}\\.(com|in|org|co.in|ac.in)$");
            var ContactNoRegex = new Regex("^[7-9]{1}[0-9]{9}$");
            var AddressRegex = new Regex("^[a-zA-Z0-9 ]{3,50}");
           
            if (string.IsNullOrEmpty(jobSeekerObj.JobSeekername) || !RegExObj.IsMatch(jobSeekerObj.JobSeekername))
            {
                IsValid = false;
                ErrorMessages.AppendLine("JobSeeker Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only 2 number of space are allowed");
            }
            //if (string.IsNullOrEmpty(jobSeekerObj.Username) || !UserNameRegex.IsMatch(jobSeekerObj.Username))
            //{
            //    IsValid = false;
            //    ErrorMessages.AppendLine("User Name should not be blank");
            //    ErrorMessages.AppendLine("Maximum 25 characters and only underscore is allowed");
            //}
            if (string.IsNullOrEmpty(jobSeekerObj.EmailAddress) || !EmailRegex.IsMatch(jobSeekerObj.EmailAddress))
            {
                IsValid = false;
                ErrorMessages.AppendLine("EmailAddress should not be blank");
                ErrorMessages.AppendLine("Maximum 30 characters are allowed and only .com, .in .org and .co.in are allowed");
            }

            if (string.IsNullOrEmpty(jobSeekerObj.ContactNumber) || !ContactNoRegex.IsMatch(jobSeekerObj.ContactNumber))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Contact Number should not be blank");
                ErrorMessages.AppendLine("Maximum 10 digits are allowed and first digit should be 7,8 or 9");
            }
            if (string.IsNullOrEmpty(jobSeekerObj.Address) || !AddressRegex.IsMatch(jobSeekerObj.Address))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Address should not be blank");
                ErrorMessages.AppendLine("Maximum 50 characters are allowed.");
            }
            int Age = DateTime.Now.Year - jobSeekerObj.DateOfBirth.Year;
            if (Age < 18 || Age > 60)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Age should be between 18 and 60");
                ErrorMessages.AppendLine("Please enter correct date of birth.");
            }
            if (string.IsNullOrEmpty(jobSeekerObj.ImagePath))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Please upload your photograph");
               
            }
            if (string.IsNullOrEmpty(jobSeekerObj.ResumePath))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Please upload your Resume");

            }

            if (IsValid == false)
            {
                throw new OnlineRecruitmentDetailsExceptions(ErrorMessages.ToString());
            }

            return IsValid;

        }
        private bool ValidateCompanyDetails(CompanyDetails CompanyDetailsObj)
        {
            var IsValid = true;
            var ErrorMessages = new StringBuilder();
            var RegExObj = new Regex("^[a-zA-Z\\s]{3,25}$");
            //var UserNameRegex = new Regex("^[a-zA-z0-9_]{3,25}");
            var DescriptionRegex = new Regex("^[a-zA-Z0-9. ]{10,200}");

           
            if (string.IsNullOrEmpty(CompanyDetailsObj.CompanyName) || !RegExObj.IsMatch(CompanyDetailsObj.CompanyName))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Company Name should not be blank");
                ErrorMessages.AppendLine("Maximum 25 characters and only single space is allowed");
            }
            //if (string.IsNullOrEmpty(CompanyDetailsObj.UserName) || !RegExObj.IsMatch(CompanyDetailsObj.UserName))
            //{
            //    IsValid = false;
            //    ErrorMessages.AppendLine("User Name should not be blank");
            //    ErrorMessages.AppendLine("Maximum 25 characters and only underscore is allowed");
            //}
            if (string.IsNullOrEmpty(CompanyDetailsObj.Description) || !DescriptionRegex.IsMatch(CompanyDetailsObj.Description))
            {
                IsValid = false;
                ErrorMessages.AppendLine("Company Description should not be blank");
                ErrorMessages.AppendLine("Maximum 200 characters is allowed in Description and Minimum 10 words required");
            }
            if (CompanyDetailsObj.CurrentStrength <= 0)
            {
                IsValid = false;
                ErrorMessages.AppendLine("Company Strength should be greater than 0 and numeric.");
            }


            if (IsValid == false)
            {
                throw new OnlineRecruitmentDetailsExceptions(ErrorMessages.ToString());
            }

            return IsValid;
        }
        public AuthenticationTableEntities Login(AuthenticationTableEntities obj)
        {
            AuthenticationTableEntities str = null;
            try
            {


                str = AuthenticationTableDAL.Login(obj);

            }


            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error", ex);
            }
            return str;
        }

        public bool Add(JobSeekerDetail JobSeekerDetailObj, AuthenticationTableEntities AuthenticationTableEntitiesObj)
        {
            var IsSaved = false;
            try
            {
                if ((Validate(AuthenticationTableEntitiesObj))&&(ValidateJobSeeker(JobSeekerDetailObj)))
                {

                    AuthenticationTableDAL obj = new AuthenticationTableDAL();
                    IsSaved = obj.AddJobSeeker(JobSeekerDetailObj, AuthenticationTableEntitiesObj);
                }
                
            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error 123", ex);
            }
            return IsSaved;
        }

        public bool AddCompany(CompanyDetails CompanyDetailsObj, AuthenticationTableEntities AuthenticationTableEntitiesObj)
        {
            var IsSaved = false;
            try
            {
                if ((Validate(AuthenticationTableEntitiesObj)) && (ValidateCompanyDetails(CompanyDetailsObj)))
                {

                    AuthenticationTableDAL obj = new AuthenticationTableDAL();
                    IsSaved = obj.AddCompanyDetails(CompanyDetailsObj, AuthenticationTableEntitiesObj);
                }
            

            }
            catch (OnlineRecruitmentDetailsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new OnlineRecruitmentDetailsExceptions("Unknown error 123", ex);
            }
            return IsSaved;
        }

    }
}

